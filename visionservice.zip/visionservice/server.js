const express = require('express');
require('dotenv').config({path: './.env'});
const app = express();
const bodyParser = require('body-parser')
const port = process.env.PORT || 8090;

const CosmosClient = require('@azure/cosmos').CosmosClient

const config = require('./config')
const url = require('url')

const endpoint = config.endpoint
const key = config.key

const databaseId = config.database.id
const containerId = config.container.id
const partitionKey = { kind: 'Hash', paths: ['/_partitionKey'] }

const client = new CosmosClient({ endpoint, key })

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

console.log(`Your port is ${port}`);

const request = require('request');

/**
 * Create the database if it does not exist
 */
async function createDatabase() {
  console.log("creating db")
  const { database } = await client.databases.createIfNotExists({
    id: databaseId
  })
  console.log(`Created database:\n${database.id}\n`)
}

/**
 * Read the database definition
 */
async function readDatabase() {
  const { resource: databaseDefinition } = await client
    .database(databaseId)
    .read()
  console.log(`Reading database:\n${databaseDefinition.id}\n`)
}

/**
 * Create the container if it does not exist
 */
async function createContainer() {
  const { container } = await client
    .database(databaseId)
    .containers.createIfNotExists(
      { id: containerId, partitionKey },
      { offerThroughput: 400 }
    )
  console.log(`Created container:\n${config.container.id}\n`)
}

/**
 * Read the container definition
 */
async function readContainer() {
  const { resource: containerDefinition } = await client
    .database(databaseId)
    .container(containerId)
    .read()
  console.log(`Reading container:\n${containerDefinition.id}\n`)
}

function iterateData (){
  const tempObj = {};

  config.items.transactions.map((item,index) => {
    tempObj[index] = item;
  });
  return tempObj;
}

/**
 * Create family item if it does not exist
 */
async function createTipData(itemBody) {
  const { item } = await client
    .database(databaseId)
    .container(containerId)
    .items.upsert(iterateData())
  console.log(`Created family item with id:\n${itemBody.id}\n`)
}

// async function triggerDb(){
//   // await createDatabase()
//   // .then(() => {
//   //   exit(`Completed successfully`)
//   // })
//   // .catch(error => {
//   //   exit(`Completed with error ${JSON.stringify(error)}`)
//   // })

//   const querySpec = {
//     query: 'SELECT * FROM root '
//   }

//   const { resources: results } = await client
//     .database(databaseId)
//     .container(containerId)
//     .items.query(querySpec)
//     .fetchAll()
//   for (var queryResult of results) {
//     let resultString = JSON.stringify(queryResult)
//     console.log(`\tQuery returned ${resultString}\n`)
//   }
// }

/**
 * Query the container using SQL
 */
async function queryContainer() {
  console.log(`Querying container:\n${config.container.id}`)

  // query to return all children in a family
  const querySpec = {
    query: 'SELECT * FROM root'
  }

  const { resources: results } = await client
    .database(databaseId)
    .container(containerId)
    .items.query(querySpec)
    .fetchAll()
  for (var queryResult of results) {
    let resultString = JSON.stringify(queryResult)
    console.log(`\tQuery returned ${resultString}\n`)
  }
}

/**
 * Exit the app with a prompt
 * @param {string} message - The message to display
 */
function exit(message) {
  console.log(message)
  console.log('Press any key to exit')
  process.stdin.setRawMode(true)
  process.stdin.resume()
  process.stdin.on('data', process.exit.bind(process, 0))
}

/**
 * Cleanup the database and collection on completion
 */
async function cleanup() {
  await client.database(databaseId).delete()
}

/**
 * getTips API
 * 
 */
app.get('/getTips', async(req, res) => {

  // createDatabase()
  // .then(() => readDatabase())
  // .then(() => createContainer())
  // .then(() => readContainer())
  // .then(() => createTipData(config.items.tips))
  // .then(() => queryContainer())
  // .then(() => {
  //   exit(`Completed successfully`)
  // })
  // .catch(error => {
  //   exit(`Completed with error ${JSON.stringify(error)}`)
  // });

  
  const obj = {};
  obj.result = await retrieveData();
  
  res.setHeader('Content-Type', 'application/json');
  res.json(obj.result);
});

 async function retrieveData(){
  const querySpec = {
    query: 'SELECT * FROM root'
  }

  let resultString = '';

  const { resources: results } =  await client
    .database(databaseId)
    .container(containerId)
    .items.query(querySpec)
    .fetchAll()
  for (var queryResult of results) {
    resultString = JSON.stringify(queryResult)
    console.log(`\tQuery returned ${resultString}\n`)
  }
  return resultString;
}



app.get('/getTxn', async (req, res) => {

  // createDatabase()
  // .then(() => readDatabase())
  // .then(() => createContainer())
  // .then(() => readContainer())
  // .then(() => createTipData(config.items.transactions))
  // .then(() => queryContainer())
  // .then(() => {
  //   exit(`Completed successfully`)
  // })
  // .catch(error => {
  //   exit(`Completed with error ${JSON.stringify(error)}`)
  // });

  const obj = {};
  obj.result = await retrieveData();
  
  res.setHeader('Content-Type', 'application/json');
  res.json(obj.result);
});


    app.listen(port, () => {
     console.log('Running with environment set to {' + process.env.NODE_ENV + '}');
     console.log('Server is up on {' + port + '}');
 }); 



