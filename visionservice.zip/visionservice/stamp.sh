MYVER=`sh ./version.sh`
sed -i "s/VERSION_PLACEHOLDER/${MYVER}/g" ./server.js
NOW=$(date +"%m-%d-%Y %r")
echo $NOW
sed -i "s/BUILD_DATE_PLACEHOLDER/${NOW}/g" ./server.js
