var config = {}

config.endpoint = 'https://trailblazerdb.documents.azure.com:443/'
config.key = '8m9weTseLkrzVy8heHyN0pF7758tokQd8uRmC0ziSJmrMeQuKAWZzbryziHm6fYg12hbT3JPV7d3xa6VQ7txtw=='

config.database = {
  id: 'co2wallet'
}

config.container = {
  id: 'Transactions'
}

config.items = {
  transactions:  [
    {
      "Transaction_Id": "1",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "17",
      "Tran_Date": "1-Aug",
      "Tran_Time": "11:25"
    },
    {
      "Transaction_Id": "2",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "19",
      "Tran_Date": "5-Aug",
      "Tran_Time": "17:10"
    },
    {
      "Transaction_Id": "3",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "21",
      "Tran_Date": "11-Aug",
      "Tran_Time": "9:29"
    },
    {
      "Transaction_Id": "4",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "22",
      "Tran_Date": "18-Aug",
      "Tran_Time": "10:15"
    },
    {
      "Transaction_Id": "5",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "28",
      "Tran_Date": "3-Sep",
      "Tran_Time": "18:30"
    },
    {
      "Transaction_Id": "6",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "7-Sep",
      "Tran_Time": "12:40"
    },
    {
      "Transaction_Id": "7",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "27",
      "Tran_Date": "14-Sep",
      "Tran_Time": "10:18"
    },
    {
      "Transaction_Id": "8",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "21",
      "Tran_Date": "16-Sep",
      "Tran_Time": "14:24"
    },
    {
      "Transaction_Id": "9",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "28",
      "Tran_Date": "19-Sep",
      "Tran_Time": "20:28"
    },
    {
      "Transaction_Id": "10",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "17",
      "Tran_Date": "22-Sep",
      "Tran_Time": "16:29"
    },
    {
      "Transaction_Id": "11",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "19",
      "Tran_Date": "29-Sep",
      "Tran_Time": "12:37"
    },
    {
      "Transaction_Id": "12",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "18",
      "Tran_Date": "1-Oct",
      "Tran_Time": "18:19"
    },
    {
      "Transaction_Id": "13",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "12",
      "Tran_Date": "4-Oct",
      "Tran_Time": "9:50"
    },
    {
      "Transaction_Id": "14",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "9-Oct",
      "Tran_Time": "20:07"
    },
    {
      "Transaction_Id": "15",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "24",
      "Tran_Date": "10-Oct",
      "Tran_Time": "14:22"
    },
    {
      "Transaction_Id": "16",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "22",
      "Tran_Date": "4-Aug",
      "Tran_Time": "20:39"
    },
    {
      "Transaction_Id": "17",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "18",
      "Tran_Date": "5-Aug",
      "Tran_Time": "13:09"
    },
    {
      "Transaction_Id": "18",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "12-Aug",
      "Tran_Time": "0:29"
    },
    {
      "Transaction_Id": "19",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "17",
      "Tran_Date": "18-Aug",
      "Tran_Time": "12:07"
    },
    {
      "Transaction_Id": "20",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "29",
      "Tran_Date": "2-Sep",
      "Tran_Time": "2:59"
    },
    {
      "Transaction_Id": "21",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "18",
      "Tran_Date": "5-Sep",
      "Tran_Time": "3:19"
    },
    {
      "Transaction_Id": "22",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "23",
      "Tran_Date": "10-Sep",
      "Tran_Time": "4:23"
    },
    {
      "Transaction_Id": "23",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "26",
      "Tran_Date": "11-Sep",
      "Tran_Time": "15:59"
    },
    {
      "Transaction_Id": "24",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "25",
      "Tran_Date": "14-Sep",
      "Tran_Time": "6:32"
    },
    {
      "Transaction_Id": "25",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "18-Sep",
      "Tran_Time": "17:19"
    },
    {
      "Transaction_Id": "26",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "18",
      "Tran_Date": "24-Sep",
      "Tran_Time": "18:07"
    },
    {
      "Transaction_Id": "27",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "17",
      "Tran_Date": "30-Sep",
      "Tran_Time": " 02:12"
    },
    {
      "Transaction_Id": "28",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "19",
      "Tran_Date": "2-Oct",
      "Tran_Time": "10:46"
    },
    {
      "Transaction_Id": "29",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "55",
      "Tran_Date": "5-Oct",
      "Tran_Time": "11:27"
    },
    {
      "Transaction_Id": "30",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "16",
      "Tran_Date": "10-Oct",
      "Tran_Time": "12:29"
    },
    {
      "Transaction_Id": "31",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "55",
      "Tran_Date": "5-Aug",
      "Tran_Time": "9:35"
    },
    {
      "Transaction_Id": "32",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "15-Aug",
      "Tran_Time": "10:35"
    },
    {
      "Transaction_Id": "33",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "26",
      "Tran_Date": "31-Aug",
      "Tran_Time": "11:35"
    },
    {
      "Transaction_Id": "34",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "29",
      "Tran_Date": "5-Sep",
      "Tran_Time": "12:35"
    },
    {
      "Transaction_Id": "35",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "34",
      "Tran_Date": "19-Sep",
      "Tran_Time": "13:35"
    },
    {
      "Transaction_Id": "36",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "39",
      "Tran_Date": "27-Sep",
      "Tran_Time": "14:35"
    },
    {
      "Transaction_Id": "37",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "41",
      "Tran_Date": "30-Sep",
      "Tran_Time": "15:35"
    },
    {
      "Transaction_Id": "38",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "44",
      "Tran_Date": "3-Oct",
      "Tran_Time": "20:39"
    },
    {
      "Transaction_Id": "39",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "52",
      "Tran_Date": "7-Oct",
      "Tran_Time": "13:09"
    },
    {
      "Transaction_Id": "40",
      "Customer_Id": "1",
      "Retail_Service_Details_Id": "42",
      "Tran_Date": "9-Oct",
      "Tran_Time": "0:29"
    },
    {
      "Transaction_Id": "41",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "51",
      "Tran_Date": "2-Aug",
      "Tran_Time": "12:07"
    },
    {
      "Transaction_Id": "42",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "54",
      "Tran_Date": "12-Aug",
      "Tran_Time": "2:59"
    },
    {
      "Transaction_Id": "43",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "46",
      "Tran_Date": "31-Aug",
      "Tran_Time": "3:19"
    },
    {
      "Transaction_Id": "44",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "37",
      "Tran_Date": "2-Sep",
      "Tran_Time": "4:23"
    },
    {
      "Transaction_Id": "45",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "46",
      "Tran_Date": "16-Sep",
      "Tran_Time": "15:59"
    },
    {
      "Transaction_Id": "46",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "27",
      "Tran_Date": "22-Sep",
      "Tran_Time": "6:32"
    },
    {
      "Transaction_Id": "47",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "28",
      "Tran_Date": "29-Sep",
      "Tran_Time": "17:19"
    },
    {
      "Transaction_Id": "48",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "31",
      "Tran_Date": "1-Oct",
      "Tran_Time": "18:07"
    },
    {
      "Transaction_Id": "49",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "51",
      "Tran_Date": "5-Oct",
      "Tran_Time": " 02:12"
    },
    {
      "Transaction_Id": "50",
      "Customer_Id": "2",
      "Retail_Service_Details_Id": "43",
      "Tran_Date": "10-Oct",
      "Tran_Time": "10:46"
    }
  ]
}

module.exports = config
